# forms.py

from django import forms
from .models import Comment

class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ['name', 'email', 'body']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'input', 'required': True}),
            'email': forms.EmailInput(attrs={'class': 'input', 'required': True}),
            'body': forms.Textarea(attrs={'class': 'textarea', 'required': True}),
        }
